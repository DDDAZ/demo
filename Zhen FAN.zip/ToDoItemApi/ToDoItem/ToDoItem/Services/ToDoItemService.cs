﻿using MongoDB.Driver;
using System.Collections.Generic;
using System.Threading.Tasks;
using ToDoItemApi.Models;

namespace ToDoItemApi.Services
{
    public class ToDoItemService
    {
        private readonly IMongoCollection<ToDoItem> _items;
        public ToDoItemService(IMongoDbSettings settings)
        {
            var client = new MongoClient(settings.Address);
            var database = client.GetDatabase(settings.DatabaseName);

            _items = database.GetCollection<ToDoItem>(settings.CollectionName);
        }

        public async Task<List<ToDoItem>> Get()
        {
            return await _items.Find(item => true).ToListAsync();
        }

        public async Task<ToDoItem> Get(string id)
        {
            return await _items.Find(item => item.Id == id).FirstOrDefaultAsync();
        }

        public async Task Add(ToDoItem itemIn)
        {
            await _items.InsertOneAsync(itemIn);
        }

        public async Task Delete(string id)
        {
            await _items.DeleteOneAsync(item => item.Id == id);
        }

        public async Task Update(string id, ToDoItem newItem)
        {
            await _items.ReplaceOneAsync(item => item.Id == id, newItem);
        }
    }
}
