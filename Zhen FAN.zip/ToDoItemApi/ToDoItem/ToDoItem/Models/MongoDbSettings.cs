﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ToDoItemApi.Models
{
    public class MongoDbSettings : IMongoDbSettings
    {
        public string DatabaseName { get; set; }
        public string CollectionName { get; set; }
        public string Address { get; set; }
    }

    public interface IMongoDbSettings
    {
        public string DatabaseName { get; set; }
        public string CollectionName { get; set; }
        public string Address { get; set; }
    }
}
