﻿using System;
using MongoDB.Bson.Serialization.Attributes;

namespace ToDoItemApi.Models
{
    public class ToDoItem
    {
        [BsonElement("id")]
        public string Id { get; set; }
        [BsonElement("description")]
        public string Description { get; set; }
        [BsonElement("createdTime")]
        public DateTime CreatedTime { get; set; }
        [BsonElement("done")]
        public bool Done { get; set; }
        [BsonElement("favorite")]
        public bool Favorite { get; set; }
        [BsonElement("children")]
        public ToDoItem[] Children { get; set; }
    }
}
