import { Router } from '@angular/router';
import { Item } from './../models/item';
import { Component, OnInit } from '@angular/core';
import { ItemService } from '../services/item.service';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  constructor(private itemService: ItemService, private router: Router) { }

  items: Item[];
  item: Item;
  addFlag: boolean;
  id: string = null;

  ngOnInit(): void {
    this.getItems();
    this.addFlag = false;
    this.item = {
      id: null,
      description: null,
      createdTime: null,
      done: true,
      favorite: true,
      children: null
    };
  }

  getItems() {
    this.itemService.getToDoItems().subscribe(data => this.items = data);
  }

  addClick() {
    this.addFlag ? this.addFlag = false : this.addFlag = true;
  }

  addItem() {
    this.item.createdTime = new Date();
    this.itemService.addToDoItem(this.item).subscribe();
  }

  reload() {
    window.location.reload();
  }

  search() {
    this.router.navigateByUrl(`/items/${this.id}`);
  }
}
