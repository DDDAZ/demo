import { ItemService } from './../services/item.service';
import { Item } from './../models/item';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-item',
  templateUrl: './item.component.html',
  styleUrls: ['./item.component.css']
})
export class ItemComponent implements OnInit {

  itemId: number;
  item: Item;
  updateFlag: boolean;
  displaySubitemFlag = false;
  createSubitemFlag = false;
  id: string;
  description: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private itemService: ItemService,
    private location: Location,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.updateFlag = false;
    this.itemId = +this.activatedRoute.snapshot.params['id'.toString()];
    if (this.itemId !== 0) {
      this.itemService.getToDoItem(this.itemId.toString())
        .subscribe(data => this.item = data);
    }
  }

  backClicked() {
    this.location.back();
  }

  updateClick() {
    this.updateFlag ? this.updateFlag = false : this.updateFlag = true;
  }

  updateItem() {
    this.itemService.updateToDoItem(this.item).subscribe();
  }

  deleteItem() {
    this.itemService.deleteTodoItem(this.item.id).subscribe();
  }

  goHome() {
    this.router.navigateByUrl('/items');
  }

  displaySubitem() {
    this.displaySubitemFlag ? this.displaySubitemFlag = false : this.displaySubitemFlag = true;
  }

  createSubitemClick() {
    this.createSubitemFlag ? this.createSubitemFlag = false : this.createSubitemFlag = true;
  }

  reload() {
    window.location.reload();
  }

  addSubitem() {

    const subitem = {
      id: this.id,
      description: this.description,
      createdTime: new Date(),
      done: true,
      favorite: true,
      children: null
    };

    this.item.children == null ? this.item.children = [subitem] : this.item.children.push(subitem);
    this.itemService.updateToDoItem(this.item).subscribe();
  }

  deleteSubitem(id: string) {

    this.item.children = this.item.children
      .map(child => child.id === id ? child = null : child = child)
      .filter(child => child != null);
    console.log(this.item.children);
    this.itemService.updateToDoItem(this.item).subscribe();
  }

  done(flag: boolean) {
    flag ? flag = false : flag = true;
  }

  favorite(flag: boolean) {
    flag ? flag = false : flag = true;
  }
}
