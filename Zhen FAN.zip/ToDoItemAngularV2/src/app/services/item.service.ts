import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs/internal/observable/of';
import { Item } from '../models/item';

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  constructor(private httpClient: HttpClient) { }

  getToDoItem(id: string): Observable<Item> {
    return this.httpClient.get<Item>(`https://localhost:5001/api/ToDoItem/${id}`)
      .pipe(catchError(this.handleError<Item>('get item id=${id}')));
  }

  getToDoItems(): Observable<Item[]> {
    return this.httpClient.get<Item[]>(`https://localhost:5001/api/ToDoItem`)
      .pipe(catchError(this.handleError('get items', [])));
  }

  updateToDoItem(item: Item) {
    return this.httpClient.put(`https://localhost:5001/api/ToDoItem/${item.id}`, item, { responseType: 'text' })
      .pipe(catchError(this.handleError<Item>('update item')));
  }

  addToDoItem(item: Item) {
    return this.httpClient.post(`https://localhost:5001/api/ToDoItem`, item, { responseType: 'text' })
      .pipe(catchError(this.handleError<Item>('add item')));
  }

  deleteTodoItem(id: string) {
    return this.httpClient.delete(`https://localhost:5001/api/ToDoItem/${id}`, { responseType: 'text' })
      .pipe(catchError(this.handleError<Item>('delete item')));
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); // log to console instead
      console.log(`${operation} failed: ${error.message}`);
      return of(result as T);
    };
  }
}
